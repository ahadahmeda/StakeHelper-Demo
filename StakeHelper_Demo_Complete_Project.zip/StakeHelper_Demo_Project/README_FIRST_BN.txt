StakeHelper DEMO Android project
================================

This archive contains the Android Gradle project source, not a prebuilt APK.

IMPORTANT: Do NOT upload this ZIP alone and expect GitHub Actions to run the workflow inside it. GitHub only detects workflow files that are already committed under .github/workflows in the repository.

Android-phone workflow:
1. Download this ZIP to your phone.
2. Use your phone's Files app to extract it.
3. Open the extracted StakeHelper_Demo_Project folder.
4. Upload ALL contents of that folder to the ROOT of a NEW GitHub repository. Preserve folders, especially app/ and .github/workflows/. Do not upload only the ZIP.
5. Commit the files. Open Actions -> Build StakeHelper Demo APK. If it did not run automatically, use Run workflow.
6. When the job succeeds, download the StakeHelper-Demo-APK artifact from the workflow run.

Build requirements: Java 17, Gradle 8.7, Android Gradle Plugin 8.5.2. GitHub Actions installs/configures these.

Limitations and safety:
- This is source code, not a verified APK. The workflow has not been confirmed on the user's GitHub repository/device.
- A successful build does not prove the overlay, screen reading, balance parsing, or AUTO behavior works in Quotex. Test only on a demo account.
- The displayed balance cannot be arbitrarily changed by the helper app; platform balance must be read from the app's interface.
- Do not use real money or assume profitability.
