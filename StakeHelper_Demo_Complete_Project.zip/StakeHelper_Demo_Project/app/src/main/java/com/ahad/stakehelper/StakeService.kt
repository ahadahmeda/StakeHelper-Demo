package com.ahad.stakehelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StakeService : AccessibilityService() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private lateinit var eng: Engine
    private var wm: WindowManager? = null
    private var box: LinearLayout? = null
    private var tv1: TextView? = null
    private var tv2: TextView? = null
    private var tv3: TextView? = null
    private var tv4: TextView? = null
    private var btnAuto: Button? = null

    private var phase = 0            // 0 = অপেক্ষা, 1 = ট্রেড চলছে
    private var idleBal = -1.0
    private var lastBal = -1.0
    private var openTime = 0L
    private var openStake = 0.0
    private var q = 1.89
    private var payPct: Int? = null
    private var lowPayout = false
    private var nextStake = 0.0
    private var stakeReady = false
    private var demoOk = false
    private var lastSetAt = 0L
    private var info = "লক্ষ্য অ্যাপ খুলুন"
    private var lastDumpText = ""

    // অটো-ট্রেড অবস্থা
    private var analyzing = false
    private var nextAllowedAt = 0L
    private var tapAt = 0L
    private var tapAttempts = 0
    private var lastDir = ""
    private var verifying = false
    private var verifyFails = 0
    private var runningCount = 0
    private var nextVerifyAt = 0L
    private var baseSigned: Set<String> = emptySet()
    private val signRe = Regex("""^\+\s*[^\d]{0,3}\s*(\d[\d,]*(?:\.\d{1,2})?)\s*[^\d\s]{0,3}$""")

    private val balRe = Regex("""^[^\d\-]{0,3}\s*(\d[\d,\s]*\.\d{1,2})\s*[^\d\s]{0,3}$""")
    private val payRe = Regex("""^\+?\s*(\d{2,3})\s*%$""")
    private val amtRe = Regex("""^[^\d]{0,3}\s*[\d.,]*\s*$""")

    private val ticker = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                info = "ত্রুটি: ${e.message}"
            }
            refreshUi()
            h.postDelayed(this, 700)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        cfg = Cfg(this)
        eng = Engine(cfg)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildPanel()
        h.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { box?.let { wm?.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------- সহায়ক ----------

    private val autoOn: Boolean get() = cfg.s("auto", "0") == "1"

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun isLocked(): Boolean = cfg.s("lockdate", "") == today()
    private fun cyclesToday(): Int = if (cfg.s("cyc_date", "") == today()) cfg.i("cyc_n", 0) else 0
    private fun incCycles() {
        val n = cyclesToday() + 1
        cfg.put("cyc_date", today())
        cfg.put("cyc_n", n.toString())
    }

    // ক্যান্ডেলের সেকেন্ড (ফোনের ঘড়ি + সেটিংয়ের ফারাক)
    private fun secOf(now: Long): Int = (((now + cfg.clockOffset * 1000L) / 1000) % 60).toInt()
    private fun nextMinute(now: Long): Long = ((now + cfg.clockOffset * 1000L) / 60000 + 1) * 60000 - cfg.clockOffset * 1000L

    private fun dayProfit(): Double = if (cfg.s("dp_date", "") == today()) cfg.d("dp_val", 0.0) else 0.0
    private fun addDayProfit(v: Double): Double {
        val n = dayProfit() + v
        cfg.put("dp_date", today())
        cfg.put("dp_val", n.toString())
        return n
    }

    private fun txt(n: AccessibilityNodeInfo): String =
        ((n.text ?: n.contentDescription)?.toString() ?: "").trim()

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int) {
        if (n == null || d > 40 || out.size > 1500) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun f2(v: Double): String = String.format(Locale.US, "%.0f", kotlin.math.floor(v.coerceAtLeast(0.0)))

    private fun findBalance(nodes: List<AccessibilityNodeInfo>): Double? {
        var best: Double? = null
        var bestTop = Int.MAX_VALUE
        val r = Rect()
        for (n in nodes) {
            if (n.isEditable) continue
            val t = txt(n)
            if (t.isEmpty() || t.length > 16) continue
            val m = balRe.find(t) ?: continue
            val v = m.groupValues[1].replace(",", "").replace(" ", "").toDoubleOrNull() ?: continue
            n.getBoundsInScreen(r)
            if (r.top in 0 until bestTop) {
                bestTop = r.top
                best = v
            }
        }
        return best
    }

    private fun findPayout(nodes: List<AccessibilityNodeInfo>): Int? {
        for (n in nodes) {
            val t = txt(n)
            if (t.isEmpty() || t.length > 8) continue
            val m = payRe.find(t) ?: continue
            val v = m.groupValues[1].toIntOrNull() ?: continue
            if (v in 50..98) return v
        }
        return null
    }

    private fun findStakeField(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? {
        for (n in nodes) {
            if (!n.isEditable) continue
            val t = txt(n)
            if (amtRe.matches(t)) return n
        }
        return null
    }

    private fun signedTexts(nodes: List<AccessibilityNodeInfo>): Set<String> {
        val out = HashSet<String>()
        for (n in nodes) {
            val t = txt(n)
            if (t.length in 2..14 && signRe.matches(t)) out.add(t)
        }
        return out
    }

    private fun parseNum(t: String): Double? = t.replace(Regex("[^0-9.]"), "").toDoubleOrNull()

    private fun dump(pkg: String, nodes: List<AccessibilityNodeInfo>) {
        val sb = StringBuilder("প্যাকেজ: $pkg\n")
        var c = 0
        val r = Rect()
        for (n in nodes) {
            val t = txt(n)
            if (t.isEmpty()) continue
            n.getBoundsInScreen(r)
            sb.append(if (n.isEditable) "[EDIT] " else "").append(t).append("  @y=").append(r.top).append('\n')
            if (++c >= 70) break
        }
        val s = sb.toString()
        if (s != lastDumpText) {
            lastDumpText = s
            Shared.lastDump = s
        }
    }

    // ফলাফল রেকর্ড + সার্কেল ফলাফলের নিয়ম (ব্যর্থ হলে আজকের জন্য বন্ধ)
    private fun record(win: Boolean, delta: Double) {
        val no = eng.trades + 1
        val r = eng.onResult(win, delta)
        val ts = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())
        TradeLog.add(cfg, "$ts|$lastDir|${f2(Math.abs(delta))}|${if (win) "W" else "L"}|$r|$no")
        lastDir = ""
        nextAllowedAt = System.currentTimeMillis() + cfg.cooldown * 1000L
        when (r) {
            "RESTART", "DONE" -> {
                incCycles()
                val dp = addDayProfit(eng.lastBank)
                info = "সার্কেল সম্পূর্ণ 🎉 (+" + f2(eng.lastBank) + ") • আজ মোট " + f2(dp)
                if (cfg.dailyTarget > 0 && dp >= cfg.dailyTarget) {
                    cfg.put("lockdate", today())
                    cfg.put("lockwhy", "TARGET")
                    info = "🎯 আজকের লাভ লক্ষ্যে পৌঁছেছে (" + f2(dp) + ") — আজ আর ট্রেড নয়"
                }
            }
            "BROKEN" -> {
                cfg.put("lockdate", today())
                cfg.put("lockwhy", "LOSS")
                info = "❌ সার্কেল ব্যর্থ — আজকের জন্য ট্রেড বন্ধ 🔒"
            }
            else -> info = if (win) "জয় ✅ +" + f2(delta) else "হার ❌ -" + f2(Math.abs(delta))
        }
    }

    // ---------- মূল লুপ ----------

    private fun tick() {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) return
        Shared.lastPkg = pkg

        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes, 0)
        dump(pkg, nodes)

        val filters = cfg.pkg.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (filters.isNotEmpty() && filters.none { pkg.lowercase().contains(it) }) {
            info = "লক্ষ্য অ্যাপ নয়: $pkg"
            return
        }

        // নতুন দিন → লক খুলে সাইকেল রিসেট
        val ld = cfg.s("lockdate", "")
        if (ld.isNotEmpty() && ld != today()) {
            cfg.put("lockdate", "")
            cfg.put("lockwhy", "")
            eng.reset()
            info = "নতুন দিন — সাইকেল রিসেট"
        }

        q = cfg.quota
        val pp = findPayout(nodes)
        payPct = pp
        lowPayout = pp != null && pp < cfg.minPayout
        demoOk = nodes.any { txt(it).lowercase().contains("demo") }
        val bal = findBalance(nodes)
        val now = System.currentTimeMillis()

        if (bal != null) {
            lastBal = bal
            if (idleBal < 0) idleBal = bal
            if (phase == 0) {
                if (idleBal - bal >= 0.99) {
                    phase = 1
                    openTime = now
                    openStake = idleBal - bal
                    tapAt = 0L
                    tapAttempts = 0
                    verifyFails = 0
                    runningCount = 0
                    verifying = false
                    nextVerifyAt = 0L
                    baseSigned = signedTexts(nodes)
                    info = "ট্রেড চলছে…"
                } else {
                    idleBal = bal
                }
            } else {
                if (bal > idleBal + 0.005) {
                    record(true, bal - idleBal)
                    phase = 0
                    idleBal = bal
                } else if (Math.abs(bal - idleBal) < 0.005) {
                    phase = 0
                    lastDir = ""
                    info = "ড্র/রিফান্ড"
                }
            }
        }

        // ট্রেড শেষ হয়েছে কিন্তু ব্যালেন্স বাড়েনি → স্ক্রিন দেখে ফলাফল ঠিক করা
        if (phase == 1 && now > tradeEnd() + cfg.settle * 1000L) resolveOpen(nodes, now)

        // স্টেক হিসাব ও বসানো
        stakeReady = false
        nextStake = eng.stake(q)
        if (phase == 0 && !eng.stopped && nextStake > 0.0 && !lowPayout) {
            var target = Math.max(kotlin.math.floor(nextStake), 1.0)
            if (lastBal > 0) target = Math.min(target, kotlin.math.floor(lastBal))
            val field = findStakeField(nodes)
            if (field == null) {
                info = "স্টেক ঘর (editable) পাওয়া যায়নি — 📋 দিয়ে কপি করুন"
            } else {
                val cur = parseNum(txt(field))
                if (cur != null && Math.abs(cur - target) <= 0.005) {
                    stakeReady = true
                } else if (now - lastSetAt > 1500) {
                    val args = Bundle()
                    args.putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, f2(target)
                    )
                    val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    lastSetAt = now
                    if (!ok) info = "স্টেক বসানো গেল না — 📋 দিয়ে কপি করুন"
                }
            }
        }

        // ট্যাপ করার পর ট্রেড না খুললে
        if (tapAt > 0 && phase == 0 && now - tapAt > 8000) {
            tapAt = 0L
            tapAttempts++
            if (tapAttempts >= 3) {
                cfg.put("auto", "0")
                tapAttempts = 0
                info = "ট্যাপে ট্রেড খোলেনি — অটো বন্ধ। Buy/Sell বাটন আবার সেট করুন"
            }
        }

        autoStep(now)
    }

    private fun tradeEnd(): Long =
        if (cfg.candleClose) nextMinute(openTime) else openTime + cfg.expiry * 1000L

    // ব্যালেন্স না বাড়লে: (১) স্ক্রিনে প্রত্যাশিত লাভের "+অঙ্ক" এসেছে কি, (২) না হলে এআই স্ক্রিনশট দেখে বলবে জয় না হার
    private fun resolveOpen(nodes: List<AccessibilityNodeInfo>, now: Long) {
        val ppx = payPct ?: Math.round((q - 1.0) * 100).toInt()
        val expProfit = openStake * ppx / 100.0
        for (t in signedTexts(nodes)) {
            if (t in baseSigned) continue
            val v = signRe.find(t)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: continue
            if (v >= expProfit * 0.75 && v <= expProfit * 1.25) {
                record(true, expProfit)
                phase = 0
                idleBal = if (lastBal > 0) lastBal else -1.0
                info = "জয় ✅ (স্ক্রিনে +" + f2(v) + " দেখা গেছে, ব্যালেন্স আপডেট হয়নি)"
                return
            }
        }
        if (!cfg.resultCheck) {
            // যাচাই বন্ধ থাকলে: ১০ সেকেন্ড বাড়তি অপেক্ষার পরেও ব্যালেন্স না বাড়লে হার ধরা হবে
            if (now > tradeEnd() + (cfg.settle + 10) * 1000L) {
                record(false, -openStake)
                phase = 0
                idleBal = if (lastBal > 0) lastBal else -1.0
            }
            return
        }
        if (verifying || now < nextVerifyAt || verifyFails >= 3) return
        verifyResult()
    }

    private fun verifyResult() {
        verifying = true
        info = "ফলাফল যাচাই চলছে (স্ক্রিন দেখে)…"
        box?.visibility = View.INVISIBLE
        h.postDelayed({
            shot { bmp ->
                h.post { box?.visibility = View.VISIBLE }
                if (bmp == null) {
                    verifying = false
                    verifyFails++
                    nextVerifyAt = System.currentTimeMillis() + 8000
                    info = "যাচাইয়ের স্ক্রিনশট পাওয়া যায়নি"
                } else {
                    Thread {
                        val res = Analyzer.checkResult(cfg, bmp)
                        h.post { onVerify(res) }
                    }.start()
                }
            }
        }, 300)
    }

    private fun onVerify(res: Analyzer.Result) {
        verifying = false
        if (phase != 1) return
        val now = System.currentTimeMillis()
        val ppx = payPct ?: Math.round((q - 1.0) * 100).toInt()
        when (res.dir) {
            "WIN" -> {
                record(true, openStake * ppx / 100.0)
                phase = 0
                idleBal = if (lastBal > 0) lastBal else -1.0
                info = "জয় ✅ (এআই স্ক্রিন দেখে নিশ্চিত)"
            }
            "LOSS" -> {
                record(false, -openStake)
                phase = 0
                idleBal = if (lastBal > 0) lastBal else -1.0
                info = "হার ❌ (এআই স্ক্রিন দেখে নিশ্চিত)"
            }
            "RUNNING" -> {
                runningCount++
                if (runningCount > 8) verifyFails++
                nextVerifyAt = now + 5000
                info = "ট্রেড এখনো চলছে বলে মনে হচ্ছে — আবার দেখবে"
            }
            else -> {
                verifyFails++
                nextVerifyAt = now + 8000
                info = if (verifyFails >= 3) "ফলাফল নিশ্চিত নয় — W বা L চাপুন" else "ফলাফল অস্পষ্ট, আবার যাচাই…"
            }
        }
    }

    // ---------- অটো-ট্রেড ----------

    private fun autoStep(now: Long) {
        if (!autoOn) return
        if (phase != 0 || analyzing) return
        if (eng.stopped) { info = "⛔ চক্র ক্লোজ — অটো থেমে আছে"; return }
        if (isLocked()) {
            info = if (cfg.s("lockwhy", "") == "TARGET") "🎯 আজকের লাভ লক্ষ্য পূর্ণ — বন্ধ" else "🔒 আজকের জন্য ট্রেড বন্ধ (সার্কেল ব্যর্থ)"
            return
        }
        val mc = cfg.maxCycles
        if (mc > 0 && cyclesToday() >= mc) { info = "🎯 আজকের সার্কেল লক্ষ্য পূর্ণ — বন্ধ"; return }
        if (lowPayout) return
        if (payPct == null) { info = "পেআউট পড়া যায়নি — অটো থেমে আছে"; return }
        if (cfg.demoGuard && !demoOk) { info = "ডেমো অ্যাকাউন্ট শনাক্ত হয়নি — অটো বন্ধ"; return }
        if (cfg.i("bx", -1) < 0 || cfg.i("sx", -1) < 0) { info = "Buy/Sell বাটন সেট করুন (📍)"; return }
        if (!stakeReady) { info = "স্টেক বসার অপেক্ষা…"; return }
        if (now < nextAllowedAt) return
        if (tapAt > 0 && now - tapAt < 8000) return
        if (secOf(now) > cfg.analyzeStart) { info = "পরের ক্যান্ডেলের শুরুর অপেক্ষা…"; return }
        analyze()
    }

    private fun analyze() {
        analyzing = true
        info = "চার্ট বিশ্লেষণ চলছে…"
        box?.visibility = View.INVISIBLE
        h.postDelayed({
            shot { bmp ->
                h.post { box?.visibility = View.VISIBLE }
                if (bmp == null) {
                    analyzing = false
                    nextAllowedAt = nextMinute(System.currentTimeMillis())
                    info = "স্ক্রিনশট পাওয়া যায়নি (Android 11+ লাগে; অ্যাপ স্ক্রিনশট ব্লক করলেও হয়)"
                } else {
                    Thread {
                        val res = Analyzer.analyze(cfg, bmp)
                        h.post { onAnalysis(res) }
                    }.start()
                }
            }
        }, 300)
    }

    private fun onAnalysis(res: Analyzer.Result) {
        analyzing = false
        val now = System.currentTimeMillis()
        if (!autoOn || phase != 0 || eng.stopped || isLocked() || !stakeReady) {
            info = "বিশ্লেষণ শেষ, কিন্তু অবস্থা বদলে গেছে — ট্রেড হয়নি"
            return
        }
        when (res.dir) {
            "UP", "DOWN" -> {
                val sec = secOf(now)
                if (sec > cfg.entryWindow) {
                    nextAllowedAt = nextMinute(now) + 500
                    info = "এআই ${res.dir} বলেছে কিন্তু দেরি হয়ে গেছে (${sec}s) — পরের ক্যান্ডেলে"
                    return
                }
                val up = res.dir == "UP"
                val x = cfg.i(if (up) "bx" else "sx", -1)
                val y = cfg.i(if (up) "by" else "sy", -1)
                lastDir = res.dir
                tapAt = now
                tapXY(x, y)
                info = "এআই: ${res.dir} → ট্যাপ (${res.note})"
            }
            "SKIP" -> {
                nextAllowedAt = nextMinute(now) + 500
                info = "এআই: SKIP (${res.note}) — পরের ক্যান্ডেলে দেখবে"
            }
            else -> {
                nextAllowedAt = nextMinute(now) + 500
                info = "এআই ত্রুটি: ${res.note}"
            }
        }
    }

    private fun shot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val b = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val copy = b?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    cb(copy)
                } catch (e: Exception) {
                    cb(null)
                }
            }

            override fun onFailure(errorCode: Int) {
                cb(null)
            }
        })
    }

    private fun tapXY(x: Int, y: Int) {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    // বাটনের অবস্থান শেখানো: স্ক্রিনজুড়ে ঝাপসা পর্দা, যেখানে ট্যাপ করবেন সেটাই সেভ হবে
    private fun calibrate(key: String, label: String) {
        val v = FrameLayout(this)
        v.setBackgroundColor(Color.parseColor("#66000000"))
        val t = TextView(this)
        t.text = "👆 $label বাটনের ঠিক ওপরে ট্যাপ করুন"
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        v.addView(t, FrameLayout.LayoutParams(-1, -1))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        v.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) {
                cfg.put(key + "x", ev.rawX.toInt().toString())
                cfg.put(key + "y", ev.rawY.toInt().toString())
                info = "$label সেট ✔ (${ev.rawX.toInt()}, ${ev.rawY.toInt()})"
                try { wm?.removeView(v) } catch (_: Exception) {}
            }
            true
        }
        wm?.addView(v, lp)
    }

    // ---------- ওভারলে প্যানেল ----------

    private fun manual(win: Boolean) {
        val amt = if (phase == 1) openStake else Math.max(eng.stake(q), 1.0)
        val pp = payPct
        val prof = if (pp != null) pp / 100.0 else q - 1.0
        record(win, if (win) amt * prof else -amt)
        phase = 0
        idleBal = -1.0
        refreshUi()
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 12f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(8, 6, 8, 6)
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        return b
    }

    private fun mkTv(size: Float): TextView {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = size
        return t
    }

    private fun buildPanel() {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.setBackgroundColor(Color.parseColor("#E6101820"))
        b.setPadding(16, 10, 16, 10)

        val title = mkTv(11f)
        title.text = "⠿ Stake Helper (ধরে টেনে সরান)"
        title.setTextColor(Color.parseColor("#9FB3C8"))
        tv1 = mkTv(12f)
        tv2 = mkTv(16f)
        tv3 = mkTv(12f)
        tv4 = mkTv(11f)
        tv4?.setTextColor(Color.parseColor("#FFD479"))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("W") { manual(true) })
        row.addView(btn("L") { manual(false) })
        row.addView(btn("↶") { eng.undo(); phase = 0; idleBal = -1.0; info = "আনডু"; refreshUi() })
        row.addView(btn("⟲") {
            eng.reset(); cfg.put("lockdate", ""); phase = 0; idleBal = -1.0
            info = "নতুন সাইকেল"; refreshUi()
        })
        row.addView(btn("📋") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("stake", f2(Math.max(nextStake, 1.0))))
            info = "কপি হয়েছে: " + f2(Math.max(nextStake, 1.0))
            refreshUi()
        })

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val ba = btn("▶ AUTO") {
            cfg.put("auto", if (autoOn) "0" else "1")
            tapAttempts = 0
            analyzing = false
            info = if (autoOn) "অটো চালু" else "অটো বন্ধ"
            refreshUi()
        }
        btnAuto = ba
        row2.addView(ba)
        row2.addView(btn("📍Buy") { calibrate("b", "Buy/Up") })
        row2.addView(btn("📍Sell") { calibrate("s", "Sell/Down") })

        b.addView(title)
        b.addView(tv1)
        b.addView(tv2)
        b.addView(tv3)
        b.addView(tv4)
        b.addView(row)
        b.addView(row2)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 12
        lp.y = 220

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        title.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (ev.rawX - sx).toInt()
                    lp.y = oy + (ev.rawY - sy).toInt()
                    wm?.updateViewLayout(b, lp)
                }
            }
            true
        }

        box = b
        wm?.addView(b, lp)
    }

    private fun refreshUi() {
        if (!::eng.isInitialized) return
        tv1?.text = "ট্রেড ${eng.trades + 1}/${cfg.events} • জয় ${eng.wins}/${cfg.expWins} • ক্যাশ ${f2(eng.cash)}"
        val pp = payPct
        when {
            isLocked() -> {
                tv2?.text = if (cfg.s("lockwhy", "") == "TARGET") "🎯 আজকের লক্ষ্য পূর্ণ — ট্রেড বন্ধ" else "🔒 আজকের জন্য ট্রেড বন্ধ"
                tv2?.setTextColor(Color.parseColor("#FF6B6B"))
            }
            eng.stopped -> {
                tv2?.text = "⛔ STOP — চক্র ক্লোজ (⟲ চাপুন)"
                tv2?.setTextColor(Color.parseColor("#FF6B6B"))
            }
            lowPayout -> {
                tv2?.text = "🚫 পেআউট কম ($pp% < ${cfg.minPayout}%) — অন্য অ্যাসেট নিন"
                tv2?.setTextColor(Color.parseColor("#FF6B6B"))
            }
            else -> {
                tv2?.text = "পরের স্টেক: ${f2(nextStake)}"
                tv2?.setTextColor(Color.parseColor("#7CFC9A"))
            }
        }
        val payTxt = if (pp != null) "$pp%" else "পড়া যায়নি ⚠️"
        tv3?.text = "পেআউট $payTxt • কোটা ${f2(cfg.quota)} • ব্যালেন্স ${if (lastBal < 0) "?" else f2(lastBal)}" +
            " • আজ লাভ ${f2(dayProfit())}/${f2(cfg.dailyTarget)}"
        tv4?.text = info
        btnAuto?.text = if (autoOn) "⏸ AUTO ON" else "▶ AUTO"
    }
}
